package com.bt.accesspoints.dao;

import static org.junit.Assert.*;

import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.bt.accesspoints.entity.AccessPoint;
import com.bt.accesspoints.entity.User;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AccessPointJpaDaoTest {
	private static AccessPointDao dao = new AccessPointJpaDao();
	private static UserDao userDao = new UserJpaDao();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("accesspoints.test");
		dao.setEntityManagerFactory(emf);
		userDao.setEntityManagerFactory(emf);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	//@Test
	public void test001Create() {
		AccessPoint ap = new AccessPoint();
		ap.setModel("m123");
		ap.setFirmwareName("Cisco2234");
		dao.create(ap);

		System.out.println("AP created " + ap.getId());
		assertNotNull(ap.getId());
	}

	//@Test
	public void test002Read() {
		AccessPoint ap = dao.read(1L);

		System.out.println("AP read " + ap.getModel());

		assertEquals("m123", ap.getModel());

	}

	//@Test
	public void test003Update() {
		AccessPoint ap = new AccessPoint();
		ap.setId(1L);
		ap.setModel("m456");
		ap.setFirmwareName("BT2234");
		dao.update(ap);

		AccessPoint ap2 = dao.read(1L);
		assertEquals("m456", ap2.getModel());
		assertEquals("BT2234", ap2.getFirmwareName());
	}

	//@Test
	public void test004Delete() {
		AccessPoint ap = new AccessPoint();
		ap.setId(1L);
		dao.delete(ap);

		AccessPoint ap2 = dao.read(1L);
		assertNull("Expecting the object to be deleted", ap2);

	}

	//@Test
	public void test005FetchByModel() {
		AccessPoint ap1 = new AccessPoint();
		ap1.setModel("m456");
		ap1.setFirmwareName("BT2234");

		AccessPoint ap2 = new AccessPoint();
		ap2.setModel("m456");
		ap2.setFirmwareName("BT2235");

		dao.create(ap1);
		dao.create(ap2);

		List<AccessPoint> apList = dao.getByModel("m456");
		assertEquals(2, apList.size());
		assertEquals("BT2234", apList.get(0).getFirmwareName());
		assertEquals("BT2235", apList.get(1).getFirmwareName());

	}

	//@Test
	public void test006UserCascadeNone() {
		AccessPoint ap1 = new AccessPoint();
		ap1.setModel("m456");
		ap1.setFirmwareName("BT2234");

		User u1 = new User();
		u1.setId("arun");
		u1.setName("Arun K");

		User u2 = new User();
		u2.setId("ram");
		u2.setName("Ram K");

		ap1.getUsers().add(u1);
		ap1.getUsers().add(u2);
		try {
			dao.create(ap1);
			fail("System should not allow to create AP with invalid user");
		} catch (Exception e) {
		}
	}

//	//@Test
	public void test007UserCascadeNone() {
		AccessPoint ap1 = new AccessPoint();
//		ap1.setId(5L);
		ap1.setModel("m456");
		ap1.setFirmwareName("BT2234");

		User u1 = new User();
		u1.setId("arun2");
		u1.setName("Arun K");

		User u2 = new User();
		u2.setId("ram2");
		u2.setName("Ram K");

		User u3 = new User();
		u3.setId("krish");
		u3.setName("Krish K");
		
		userDao.create(u1);
		userDao.create(u2);
		userDao.create(u3);

//		try {
//			dao.create(ap1);
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//			e.printStackTrace();
//			fail("System should have created AP");
//		}

		ap1.getUsers().add(u1);
		ap1.getUsers().add(u2);
		ap1.getUsers().add(u3);
		
		try {
			dao.create(ap1);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			fail("System should have associated AP with user");
		}
	}

	@Test
	public void test008Dummy() {
	}
	
	@Test
	public void test008UserCascadeNone() {
		AccessPoint ap1 = new AccessPoint();
		ap1.setModel("m456");
		ap1.setFirmwareName("BT2234");
		
		User u1 = new User();
		u1.setId("arun2");
		u1.setName("Arun K");

		User u2 = new User();
		u2.setId("ram2");
		u2.setName("Ram K");

		User u3 = new User();
		u3.setId("krish");
		u3.setName("Krish K");

		ap1.getUsers().add(u1);
		ap1.getUsers().add(u2);
		ap1.getUsers().add(u3);
		
		userDao.create(u1);
		userDao.create(u2);
		userDao.create(u3);
		
		dao.create(ap1);
		
		ap1.setFirmwareName("xxxxxx");
		
		ap1.getUsers().iterator().next().setName("YYYYYYYYY");
		
		dao.update(ap1);
		
//		userDao.create(u1);
//		userDao.create(u2);
//		userDao.create(u3);

//		try {
//			dao.create(ap1);
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//			e.printStackTrace();
//			fail("System should have created AP");
//		}

		ap1.getUsers().add(u1);
		ap1.getUsers().add(u2);
		ap1.getUsers().add(u3);
		
		try {
			dao.create(ap1);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			fail("System should have associated AP with user");
		}
	}

}
