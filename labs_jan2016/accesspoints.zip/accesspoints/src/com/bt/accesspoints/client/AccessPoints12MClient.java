package com.bt.accesspoints.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.bt.accesspoints.entity.AccessPoint;
import com.bt.accesspoints.entity.Antenna;
import com.bt.accesspoints.entity.Port;
import com.bt.accesspoints.entity.PortType;

public class AccessPoints12MClient {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("accesspoints");
		EntityManager em = factory.createEntityManager();
		
		em.getTransaction().begin();
		
		AccessPoint ap = new AccessPoint();
		ap.setModel("m1");
		ap.setFirmwareName("Cisco35");
		
		Port p = new Port();
		p.setId(5L);
		p.setPortType(PortType.RS15);
		ap.setPort(p);
		
		Antenna ant1 = new Antenna();
		ant1.setType("ANT1");
		ant1.setAccesspoint(ap);
		
		Antenna ant2 = new Antenna();
		ant2.setType("ANT2");
		ant2.setAccesspoint(ap);
		
		ap.getAntennas().add(ant1);
		ap.getAntennas().add(ant2);
		
		em.persist(ap);

		em.getTransaction().commit();
	}

}
