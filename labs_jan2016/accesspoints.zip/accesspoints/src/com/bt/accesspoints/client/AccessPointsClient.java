package com.bt.accesspoints.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.bt.accesspoints.entity.AccessPoint;

public class AccessPointsClient {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("accesspoints");
		EntityManager em = factory.createEntityManager();
		
		em.getTransaction().begin();
		
		AccessPoint ap = new AccessPoint();
		ap.setModel("m123");
		ap.setFirmwareName("Cisco2234");
		
		em.persist(ap);
		em.flush();
		
//		em.detach(ap);
		
		ap.setModel("m456");
		em.getTransaction().commit();
	}

}
