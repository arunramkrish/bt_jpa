package com.bt.accesspoints.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.bt.accesspoints.entity.AccessPoint;
import com.bt.accesspoints.entity.Port;
import com.bt.accesspoints.entity.PortType;

public class AccessPoints121Client {

/*	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("accesspoints");
		EntityManager em = factory.createEntityManager();
		
		em.getTransaction().begin();
		
		AccessPoint ap = new AccessPoint();
		ap.setModel("m123");
		ap.setFirmwareName("Cisco2234");
		
		Port p = new Port();
		p.setId(2L);
		p.setPortType(PortType.RJ45);
		ap.setPort(p);

		em.persist(ap);

		em.getTransaction().commit();
	}
*/
	
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("accesspoints");
		EntityManager em = factory.createEntityManager();
		
		em.getTransaction().begin();
		
		AccessPoint ap = new AccessPoint();
		ap.setId(65536L);
		ap.setModel("m1");
		ap.setFirmwareName("Cisco35");
		
		Port p = new Port();
		p.setId(1L);
		p.setPortType(PortType.RS15);
		ap.setPort(p);

		em.merge(ap);

		em.getTransaction().commit();
	}

}
