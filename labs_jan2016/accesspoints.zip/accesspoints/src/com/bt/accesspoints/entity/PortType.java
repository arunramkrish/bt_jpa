package com.bt.accesspoints.entity;

public enum PortType {
	RS15, RJ45;
}
