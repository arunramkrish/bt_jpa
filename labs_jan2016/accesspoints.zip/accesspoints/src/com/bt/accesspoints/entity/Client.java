package com.bt.accesspoints.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Client extends BaseEntity {
	@Id
	private String id;
	
	@Column(name="client_type", nullable = false, length=25)
	private String clientType;
}
