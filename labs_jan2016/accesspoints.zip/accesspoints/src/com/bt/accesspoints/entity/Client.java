package com.bt.accesspoints.entity;

public class Client {
	
}
