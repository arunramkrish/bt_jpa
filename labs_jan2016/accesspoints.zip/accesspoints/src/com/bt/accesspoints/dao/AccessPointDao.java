package com.bt.accesspoints.dao;

import java.util.Set;

import com.bt.accesspoints.entity.AccessPoint;
import com.bt.accesspoints.entity.Antenna;

public interface AccessPointDao extends GenericDao<AccessPoint, Long>{
	Set<Antenna> getAntennas(Long accessPointId);
}
