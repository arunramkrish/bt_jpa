package com.bt.accesspoints.dao;

import java.util.Set;

import com.bt.accesspoints.entity.AccessPoint;
import com.bt.accesspoints.entity.Antenna;

public class AccessPointJpaDao extends GenericDaoJpaImpl<AccessPoint, Long>
		implements AccessPointDao {

	@Override
	public Set<Antenna> getAntennas(Long accessPointId) {
//		entityManager.clear();
		return null;
	}
	
}
