package com.bt.accesspoints.dao;

import java.util.List;
import java.util.Set;

import javax.persistence.TypedQuery;

import com.bt.accesspoints.entity.AccessPoint;
import com.bt.accesspoints.entity.Antenna;

public class AccessPointJpaDao extends GenericDaoJpaImpl<AccessPoint, Long>
		implements AccessPointDao {

	@Override
	public Set<Antenna> getAntennas(Long accessPointId) {
		// entityManager.clear();
		return null;
	}

	@Override
	public List<AccessPoint> getByModel(String model) {
		TypedQuery<AccessPoint> query = entityManager.createNamedQuery(
				"accessPointByModel", AccessPoint.class);
		query.setParameter("model", model);

		return query.getResultList();
	}

}
