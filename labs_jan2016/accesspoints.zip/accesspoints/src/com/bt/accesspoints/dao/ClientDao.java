package com.bt.accesspoints.dao;

import com.bt.accesspoints.entity.Client;

public interface ClientDao extends GenericDao<Client, String>{

}
