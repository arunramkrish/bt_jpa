package com.bt.accesspoints.dao;

import java.io.Serializable;

import javax.persistence.EntityManagerFactory;

import com.bt.accesspoints.entity.BaseEntity;

public interface GenericDao<T extends BaseEntity, PK 
	extends Serializable> {
	
	T create(T t);

	T read(PK id);

	T update(T t);

	void delete(T t);

	void setEntityManagerFactory(EntityManagerFactory entityManagerFactory);
}
