package com.bt.accesspoints.servlet;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bt.accesspoints.dao.AccessPointDao;
import com.bt.accesspoints.dao.AccessPointJpaDao;
import com.bt.accesspoints.entity.AccessPoint;

/**
 * Servlet implementation class AccessPointServlet
 */
@WebServlet("/ap/*")
public class AccessPointServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private AccessPointDao dao = new AccessPointJpaDao();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AccessPointServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("accesspoints");
		dao.setEntityManagerFactory(emf);

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		if (request.getRequestURI().endsWith("create")) {

			AccessPoint ap = new AccessPoint();
			ap.setModel("m123");
			ap.setFirmwareName("Cisco2234");
			dao.create(ap);

			System.out.println("AP created " + ap.getId());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
