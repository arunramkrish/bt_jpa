package com.bt.accesspoints.dao;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.bt.accesspoints.entity.AccessPoint;
import com.bt.accesspoints.entity.User;

public class UserJpaDao extends GenericDaoJpaImpl<User, String> implements
		UserDao {

	@Override
	public List<AccessPoint> getAccessPointsForUser(String userName) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<AccessPoint> query = builder
				.createQuery(AccessPoint.class);

		Root<User> root = query.from(User.class);
		
		Expression<AccessPoint> apExpr = root.get("accessPoints");

		Expression<String> expr = root.get("userName");
		Predicate like = builder.like(builder.upper(expr),
				"%" + userName.toUpperCase() + "%");

		query.distinct(true);

		query.select(apExpr);
		query.where(like);

		TypedQuery<AccessPoint> typedQuery = entityManager.createQuery(query);

		return typedQuery.getResultList();
	}

}
