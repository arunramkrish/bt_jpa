package com.bt.accesspoints.dao;

import com.bt.accesspoints.entity.Client;

public class ClientJpaDao extends GenericDaoJpaImpl<Client, String> implements
		ClientDao {

}
