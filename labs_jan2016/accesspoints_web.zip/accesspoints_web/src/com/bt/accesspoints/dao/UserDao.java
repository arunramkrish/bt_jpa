package com.bt.accesspoints.dao;

import java.util.List;

import com.bt.accesspoints.entity.AccessPoint;
import com.bt.accesspoints.entity.User;

public interface UserDao extends GenericDao<User, String>{
	List<AccessPoint> getAccessPointsForUser(String userName);
}
