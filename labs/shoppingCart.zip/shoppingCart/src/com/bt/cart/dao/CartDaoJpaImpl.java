package com.bt.cart.dao;

import com.bt.cart.entity.Cart;

public class CartDaoJpaImpl extends GenericDaoJpaImpl<Cart, Long> implements CartDao {
	
}
