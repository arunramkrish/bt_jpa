package com.bt.cart.dao;

import com.bt.cart.entity.User;

public interface UserDao extends GenericDao<User, Long> {

}
