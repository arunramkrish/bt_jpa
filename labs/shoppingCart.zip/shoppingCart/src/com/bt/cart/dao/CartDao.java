package com.bt.cart.dao;

import com.bt.cart.entity.Cart;

public interface CartDao extends GenericDao<Cart, Long> {

}
