package com.bt.cart.dao;

import com.bt.cart.entity.User;

public class UserDaoJpaImpl extends GenericDaoJpaImpl<User, Long> implements UserDao {
	
}
