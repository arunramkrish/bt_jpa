package com.bt.jpa.entity;

/**
 * Role of an employee in the project
 * 
 * @author arun
 * 
 */
public enum ProjectRole {
	MANAGER, MEMBER, QA, ARCHITECT;
}
